Benjamin Brickner | CS360 | Assignment 1 | wordPair

Usage: ./wordPair <-count> fileName <fileName2> <fileName 3> ...

Note: There is a limit of 10 arguments


wordPair is a program that counts how many same pair of words appear in a text file and sorts it from most occurance to least. 

The zip file contains a Makefile.  To compile, enter "make" into the terminal. Then, after it compiles, use the command above to run it.
If you want to clean the object files, do "make clean" in the terminal. 

<-count> determines the top x (x being the count provided) most appeared pair of words. 

A text file MUST be provided in order to run this.


The c files "crc_64" and "getWord" are given by Ben McCamish for this program. 
